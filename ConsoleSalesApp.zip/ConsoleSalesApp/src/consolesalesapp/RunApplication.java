package consolesalesapp;

import java.util.Scanner;

public class RunApplication {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Interactive console selection menu
        System.out.println("Select the console type");
        System.out.println("1) PS5");
        System.out.println("2) XBOX");
        System.out.println("3) SWITCH");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Clear scanner buffer

        String consoleType = "";
        switch (choice) {
            case 1:
                consoleType = "PS5";
                break;
            case 2:
                consoleType = "XBOX";
                break;
            case 3:
                consoleType = "SWITCH";
                break;
            default:
                consoleType = "PS5";
                break;
        }

        // Get user inputs for store name and total sales
        System.out.print("Enter the store: ");
        String storeName = scanner.nextLine();

        System.out.print("Enter the total sales of " + consoleType + " consoles for " + storeName + ": ");
        int totalSales = scanner.nextInt();

        System.out.println(); 

        // Create ConsoleSales object and invoke print report method
        ConsoleSales salesReport = new ConsoleSales(consoleType, storeName, totalSales);
        salesReport.printReport();

        scanner.close();
    }
}