package consolesalesapp;

// Interface establishing contract for console sales getters
public interface IConsole {
    String getConsoleType();
    String getStore();
    int getTotalSales();
}