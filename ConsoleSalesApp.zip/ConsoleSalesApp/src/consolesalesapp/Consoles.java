package consolesalesapp;

// Abstract parent class implementing IConsole interface
public abstract class Consoles implements IConsole {
    private String consoleType;
    private String storeName;
    private int totalSales;

    // Constructor to set console data
    public Consoles(String consoleType, String storeName, int totalSales) {
        this.consoleType = consoleType;
        this.storeName = storeName;
        this.totalSales = totalSales;
    }

    @Override
    public String getConsoleType() {
        return consoleType;
    }

    @Override
    public String getStore() {
        return storeName;
    }

    @Override
    public int getTotalSales() {
        return totalSales;
    }
}